import math


class Mass:
    electron = 9.1 * (math.pow(10, -31))
    proton = 1.67 * (math.pow(10, -27))
    neutron = 1.67 * (math.pow(10, -27))

import math


class Charge:
    electron = 1.602 * (math.pow(10, -19))

# PhysiPy

## Physics Equation Solver and Constants for Python


PhysiPy is a powerful and versatile Python library designed to streamline physics calculations and provide easy access to a vast collection of essential physical constants. Whether you are a student, researcher, or an enthusiast seeking to explore the intricacies of the physical world, PhysiPy is an indispensable tool for your scientific endeavors.

With PhysiPy, you can effortlessly perform complex physics computations without the need for extensive manual coding. The library encompasses a wide range of formulas and equations spanning various branches of physics, including mechanics, electromagnetism, thermodynamics, quantum mechanics, and more. From simple kinematic equations to intricate quantum mechanical wavefunctions, PhysiPy has you covered, simplifying the process of implementing these calculations into your code.

One of the key features of PhysiPy is its extensive collection of physical constants. It contains hundreds of well-documented and up-to-date constants that are crucial for numerous calculations and experiments. These constants encompass fundamental values such as the speed of light, Planck's constant, elementary charge, Avogadro's number, and many more. By having this wealth of constants readily available, PhysiPy eliminates the need to search for and manually input these values, ensuring accuracy and efficiency in your calculations.

## Installation

`pip install PhysiPy-Python`


### Alternatively, you can install it via the given .targz file. Here are the steps:

- Download the `PhysiPy-1.0.0.tar.gz` file from the `dist` folder in the repository
- Now, copy the path of the downloaded `.tar.gz` file
- Open Terminal and type in the following command:
`pip install <path you've copied>`


## Features in a Glance

- Over 100 pre-defined Physics Equations (Just substitute the values inside function)
- Over 150+ constants (including Boltzmann Constant, Gravitational Constants, and much more)
- Extremely quick since it uses Numpy

## Demo Snippets

`
# to calculate resistance

import PhysiPy

a = PhysiPy.Electricity.resistance(25, 10)
print(a)

>> 2.5
`
import numpy as np
import math

# constants
g = 9.8
G = 6.67408 * (math.pow(10, -11))
speed_of_light = 3 * 10 ^ 8
pi = math.pi
e = math.e
epsilon0 = 8.854187817 * (math.pow(10, -12))
permittivity_of_free_space = 9 * (math.pow(10, 9))
plancks_constant = 6.62607015 * (math.pow(10, -34))
elementary_charge = 1.602176634  * (math.pow(10, -19))
vonklitzing_constant = 25812.80745
compton_wavelength = 2.42 * (math.pow(10, -12))
finestructure_constant = 0.007297351
bohr_radius = 0.0529
faraday_constant = 96485
boltzmann_constant = 1.38064  * (math.pow(10, -23))
thomson_crosssection = 6.6524  * (math.pow(10, -29))

def weight(mass):
    result = mass * 9.8
    return result

def density(mass, volume):
    result = mass/volume
    return result

def volume(L, B, H):
    print("Volume:", L * B * H)

def area(L, B):
    print("Area:", L * B)

class Gravitation:
    def __init__(self):
        super().__init__()

    @staticmethod
    def G(m1, m2, r):
        rsq = r*r
        result = G * ((m1*m2)/rsq)
        return result

    @staticmethod
    def G_Potential(M, r):
        v = (-G * M) / r
        return v

    @staticmethod
    def g_in_depth(depth):
        res = g * (1-(depth/6400))
        return res

    @staticmethod
    def axial_velocity(area_swept, time):
        return area_swept/time

class Nlm:
    def __init__(self):
        super().__init__()

    @staticmethod
    def force(mass, acceleration):
        return mass * acceleration

    @staticmethod
    def momentum(mass, velocity):
        return mass * velocity

class Kinematics:
    def __init__(self):
        super().__init__()

    @staticmethod
    def speed(distance, time):
        result = distance / time
        return result

    @staticmethod
    def velocity(displacement, time):
        return displacement / time

    @staticmethod
    def displacement(velocity, time):
        return velocity * time

    @staticmethod
    def distance(speed, time):
        return speed * time

    @staticmethod
    def acceleration(u, v, dt):
        return (v - u) / dt

    @staticmethod
    def time(distance, speed):
        return distance / speed

class Errors:
    def __init__(self):
        super().__init__()

    @staticmethod
    def error_muldiv(a, b, c, d):
        x = ((a / c) + (b / d))
        return x

    @staticmethod
    def error_addsub(a, b):
        p = (a + b)
        return p

    @staticmethod
    def percentage_error(M, E):
        print("Percentage Error:", (M / E) * 100, "%")

    @staticmethod
    def absolute_error(a, n):
        if len(a) == n:
            A = np.array(a)
            S = np.sum(A)
            E = S / n
            return E
        else:
            return ValueError

    @staticmethod
    def meanabsolute_error(a, n):
        if len(a) == n:
            b = []
            for i in a:
                b.append(abs(i))
            A = np.array(b)
            S = np.sum(A)
            M = S / n
            return M
        else:
            print("error try again")

class Electricity:
    def __init__(self):
        super().__init__()

    @staticmethod
    def force_electrostatics(q1, q2, r):
        r = r*r
        y = (q1 * q2) / r
        x = permittivity_of_free_space * y
        return x

    @staticmethod
    def resistance(voltage, current):
        p = (voltage/ current)
        return p

    @staticmethod
    def current(voltage, resistance):
        return voltage/resistance

    @staticmethod
    def voltage(current, resistance):
        return current*resistance

class Subatomic:
    def __init__(self):
        super().__init__()

    class Mass:
        electron = 9.1 * (math.pow(10, -31))
        proton = 1.67 * (math.pow(10, -27))
        neutron = 1.67 * (math.pow(10, -27))

    class Charge:
        electron = 1.602 * (math.pow(10, -19))